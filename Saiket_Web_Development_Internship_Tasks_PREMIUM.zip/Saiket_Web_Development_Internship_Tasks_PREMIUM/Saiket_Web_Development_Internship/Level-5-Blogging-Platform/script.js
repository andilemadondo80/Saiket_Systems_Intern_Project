const STORAGE_KEY = "devjournal-posts-v1";
const seedPosts = [
  { id: crypto.randomUUID(), title: "Why semantic HTML matters", category: "Web Development", body: "Semantic HTML creates meaningful structure, improves accessibility and makes a codebase easier for other developers to understand.", date: new Date().toISOString() },
  { id: crypto.randomUUID(), title: "Building projects that solve real problems", category: "Projects", body: "A strong project starts with a clear problem. Features should support the user rather than exist only to make the application look complex.", date: new Date().toISOString() }
];

const editor = document.querySelector("#editor");
const form = document.querySelector("#postForm");
const list = document.querySelector("#postList");
const postCount = document.querySelector("#postCount");
let editingId = null;

function getPosts() {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : seedPosts;
}

function savePosts(posts) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
}

function renderPosts() {
  const posts = getPosts();
  postCount.textContent = `${posts.length} published post${posts.length === 1 ? "" : "s"}`;
  list.innerHTML = posts.map(post => `
    <article class="post">
      <span class="badge">${escapeHtml(post.category)}</span>
      <h3>${escapeHtml(post.title)}</h3>
      <div class="post-meta">${new Date(post.date).toLocaleDateString("en-ZA")}</div>
      <p>${escapeHtml(post.body)}</p>
      <div class="post-actions">
        <button type="button" data-edit="${post.id}">Edit</button>
        <button type="button" data-delete="${post.id}">Delete</button>
      </div>
    </article>
  `).join("");
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[char]));
}

function openCreate() {
  editingId = null;
  form.reset();
  document.querySelector("#editorTitle").textContent = "Create a post";
  editor.showModal();
}

document.querySelector("#openEditor").addEventListener("click", openCreate);

document.querySelector("#cancelEditor").addEventListener("click", () => editor.close());

form.addEventListener("submit", event => {
  event.preventDefault();
  const posts = getPosts();
  const data = {
    title: document.querySelector("#title").value.trim(),
    category: document.querySelector("#category").value,
    body: document.querySelector("#body").value.trim()
  };

  if (!form.reportValidity()) return;

  if (editingId) {
    const index = posts.findIndex(post => post.id === editingId);
    posts[index] = { ...posts[index], ...data };
  } else {
    posts.unshift({ id: crypto.randomUUID(), ...data, date: new Date().toISOString() });
  }

  savePosts(posts);
  editor.close();
  renderPosts();
});

list.addEventListener("click", event => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;
  const posts = getPosts();

  if (editId) {
    const post = posts.find(item => item.id === editId);
    editingId = editId;
    document.querySelector("#editorTitle").textContent = "Edit post";
    document.querySelector("#title").value = post.title;
    document.querySelector("#category").value = post.category;
    document.querySelector("#body").value = post.body;
    editor.showModal();
  }

  if (deleteId) {
    savePosts(posts.filter(post => post.id !== deleteId));
    renderPosts();
  }
});

document.querySelector("#clearPosts").addEventListener("click", () => {
  localStorage.removeItem(STORAGE_KEY);
  renderPosts();
});

renderPosts();
