# Saiket Systems — Web Development Internship Tasks

This submission contains six separate, runnable levels matching the internship task brief.

## Levels

1. **Online Portfolio Website** — semantic HTML, responsive CSS, JavaScript form validation.
2. **E-commerce Product Page** — product UI, quantity controls and cart interaction.
3. **Simple Navigation Menu** — responsive navigation, anchor links and active-section feedback.
4. **HTML Forms** — text input, radio buttons, checkboxes, dropdown, validation and user feedback.
5. **Blogging Platform** — create, edit, publish and delete posts with browser localStorage persistence.
6. **Interactive Web Application** — focus timer, task tracker, live progress and localStorage persistence.

## How to run

Open each level's `index.html` in a modern browser. No framework, build tool or external dependency is required.

## Code quality choices

- Semantic HTML5 structure.
- Responsive layouts.
- Accessible labels and ARIA status messaging where interaction requires it.
- Reusable CSS variables and components.
- Small, focused JavaScript functions.
- Client-side validation.
- HTML escaping before dynamically rendering user-entered blog/task content.
- `localStorage` is used only for the demo's client-side persistence.
- No copied third-party code or external framework dependency.

## Visual design

The visual system uses a premium navy-and-black gradient, subtle blue accents, glass-like dark surfaces, restrained glow, and responsive spacing while preserving the original functionality and structure.
