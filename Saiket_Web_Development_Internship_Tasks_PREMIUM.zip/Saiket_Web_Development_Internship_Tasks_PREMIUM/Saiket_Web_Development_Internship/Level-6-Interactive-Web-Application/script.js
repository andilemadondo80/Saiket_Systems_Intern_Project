const TASK_KEY = "devdash-tasks-v1";
let seconds = 25 * 60;
let intervalId = null;

const timer = document.querySelector("#timer");
const taskList = document.querySelector("#taskList");
const progressBar = document.querySelector("#progressBar");
const progressText = document.querySelector("#progressText");

function renderTimer() {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const remaining = (seconds % 60).toString().padStart(2, "0");
  timer.textContent = `${minutes}:${remaining}`;
}

function renderTasks() {
  const tasks = JSON.parse(localStorage.getItem(TASK_KEY) || "[]");
  taskList.innerHTML = tasks.map((task, index) => `
    <li class="task-item ${task.done ? "done" : ""}">
      <input type="checkbox" ${task.done ? "checked" : ""} data-toggle="${index}" aria-label="Mark ${escapeHtml(task.text)} complete">
      <span>${escapeHtml(task.text)}</span>
      <button type="button" data-delete="${index}" aria-label="Delete ${escapeHtml(task.text)}">Delete</button>
    </li>
  `).join("");

  const completed = tasks.filter(task => task.done).length;
  const percentage = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
  progressBar.style.width = `${percentage}%`;
  progressText.textContent = `${percentage}% complete · ${completed}/${tasks.length} completed`;
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[char]));
}

document.querySelector("#start").addEventListener("click", () => {
  if (intervalId) return;
  intervalId = setInterval(() => {
    seconds = Math.max(0, seconds - 1);
    renderTimer();
    if (seconds === 0) {
      clearInterval(intervalId);
      intervalId = null;
      alert("Focus session complete!");
    }
  }, 1000);
});

document.querySelector("#pause").addEventListener("click", () => {
  clearInterval(intervalId);
  intervalId = null;
});

document.querySelector("#reset").addEventListener("click", () => {
  clearInterval(intervalId);
  intervalId = null;
  seconds = 25 * 60;
  renderTimer();
});

document.querySelector("#taskForm").addEventListener("submit", event => {
  event.preventDefault();
  const input = document.querySelector("#taskInput");
  const text = input.value.trim();
  if (!text) return;

  const tasks = JSON.parse(localStorage.getItem(TASK_KEY) || "[]");
  tasks.push({ text, done: false });
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks));
  input.value = "";
  renderTasks();
});

taskList.addEventListener("change", event => {
  const index = event.target.dataset.toggle;
  if (index === undefined) return;

  const tasks = JSON.parse(localStorage.getItem(TASK_KEY) || "[]");
  tasks[index].done = event.target.checked;
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks));
  renderTasks();
});

taskList.addEventListener("click", event => {
  const index = event.target.dataset.delete;
  if (index === undefined) return;

  const tasks = JSON.parse(localStorage.getItem(TASK_KEY) || "[]");
  tasks.splice(Number(index), 1);
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks));
  renderTasks();
});

document.querySelector("#clearCompleted").addEventListener("click", () => {
  const tasks = JSON.parse(localStorage.getItem(TASK_KEY) || "[]");
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks.filter(task => !task.done)));
  renderTasks();
});

renderTimer();
renderTasks();
