document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#contactForm");
  const fields = ["name", "email", "message"];

  function showError(name, message) {
    const target = document.querySelector(`[data-error-for="${name}"]`);
    if (target) target.textContent = message;
  }

  function validate() {
    let valid = true;
    fields.forEach(name => showError(name, ""));

    const name = document.querySelector("#name");
    const email = document.querySelector("#email");
    const message = document.querySelector("#message");

    if (!name.value.trim()) {
      showError("name", "Please enter your name.");
      valid = false;
    }

    if (!email.validity.valid || !email.value.trim()) {
      showError("email", "Please enter a valid email address.");
      valid = false;
    }

    if (!message.value.trim()) {
      showError("message", "Please enter a message.");
      valid = false;
    }

    return valid;
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    const success = document.querySelector("#formSuccess");
    success.classList.add("hidden");

    if (validate()) {
      success.classList.remove("hidden");
      form.reset();
    }
  });
});
