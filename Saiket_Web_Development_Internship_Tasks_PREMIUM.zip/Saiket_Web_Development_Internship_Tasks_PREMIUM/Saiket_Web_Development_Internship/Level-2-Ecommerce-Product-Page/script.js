const price = 1499;
let quantity = 1;
let cartCount = 0;

const quantityOutput = document.querySelector("#quantity");
const cartCountOutput = document.querySelector("#cartCount");
const cartMessage = document.querySelector("#cartMessage");

function renderQuantity() {
  quantityOutput.value = quantity;
  quantityOutput.textContent = quantity;
}

document.querySelector("#minus").addEventListener("click", () => {
  quantity = Math.max(1, quantity - 1);
  renderQuantity();
});

document.querySelector("#plus").addEventListener("click", () => {
  quantity = Math.min(10, quantity + 1);
  renderQuantity();
});

document.querySelector("#addToCart").addEventListener("click", () => {
  cartCount += quantity;
  cartCountOutput.textContent = cartCount;
  cartMessage.textContent = `${quantity} item(s) added to your cart — subtotal R${(price * quantity).toLocaleString("en-ZA")}.`;
  cartMessage.classList.remove("hidden");
});
