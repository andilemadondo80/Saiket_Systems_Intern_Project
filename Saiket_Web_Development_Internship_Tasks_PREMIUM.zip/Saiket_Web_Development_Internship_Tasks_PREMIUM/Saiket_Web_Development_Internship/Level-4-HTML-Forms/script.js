const form = document.querySelector("#contactForm");

const errorMap = {
  fullName: document.querySelector("#fullNameError"),
  email: document.querySelector("#emailError"),
  topic: document.querySelector("#topicError"),
  method: document.querySelector("#methodError"),
  message: document.querySelector("#messageError")
};

function clearErrors() {
  Object.values(errorMap).forEach(element => element.textContent = "");
}

form.addEventListener("submit", event => {
  event.preventDefault();
  clearErrors();

  const name = document.querySelector("#fullName");
  const email = document.querySelector("#email");
  const topic = document.querySelector("#topic");
  const message = document.querySelector("#message");
  const method = document.querySelector('input[name="contactMethod"]:checked');

  let valid = true;

  if (name.value.trim().length < 2) {
    errorMap.fullName.textContent = "Please enter your full name.";
    valid = false;
  }
  if (!email.validity.valid) {
    errorMap.email.textContent = "Please enter a valid email address.";
    valid = false;
  }
  if (!topic.value) {
    errorMap.topic.textContent = "Please choose a reason for contact.";
    valid = false;
  }
  if (!method) {
    errorMap.method.textContent = "Please select a preferred contact method.";
    valid = false;
  }
  if (message.value.trim().length < 20) {
    errorMap.message.textContent = "Message must contain at least 20 characters.";
    valid = false;
  }

  const success = document.querySelector("#success");
  success.classList.add("hidden");

  if (valid) {
    success.textContent = "Form submitted successfully. All required fields passed validation.";
    success.classList.remove("hidden");
    form.reset();
  }
});
